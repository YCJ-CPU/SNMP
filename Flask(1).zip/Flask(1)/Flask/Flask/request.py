﻿import re
import psutil
import time
from scapy.all import *
from scapy.layers.l2 import ARP
from Flask.my_database import *

# 检查网卡是否连接到输入的IP地址所在的网络
def is_connected_to_network(ip, iface):
    try:
        # 获取目标IP的子网掩码（假设使用默认的C类子网掩码）
        subnet = '.'.join(ip.split('.')[:-1]) + '.0/24'  # 假设为C类地址
        ans, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=subnet), timeout=0, iface=iface, verbose=False)
        return len(ans) > 0
    except Exception as e:
        print(f"{iface}检查网络连接时出错: {e}")
        return -1

# 检查输入的IP地址是否有效
def is_valid_ip(ip):
    pattern = r'^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    return re.match(pattern, ip) is not None

# 本地网络接口信息
class NetworkInterface:
    # 获取所有网络接口
    interfaces = psutil.net_if_addrs()

    # 获取指定IP地址所在的网络接口（如果找不到，返回None）
    @staticmethod
    def get_interface_by_ip(destination_ip):
        for iface in NetworkInterface.interfaces.keys():
            if is_connected_to_network(destination_ip, iface):
                return iface
        return None

    @staticmethod
    def get_active_interfaces():
        active_interfaces = {}
        for iface, addrs in NetworkInterface.interfaces.items():
            for addr in addrs:
                # 过滤出有IPv4地址的接口
                if addr.family == socket.AF_INET:
                    active_interfaces[iface] = addr.address
        return active_interfaces

# ICMP包请求
class ICMPRequest:
    @staticmethod
    def add_data_to_icmp_database(pkt):
        m_source = pkt[IP].src
        m_destination = pkt[IP].dst
        m_type = pkt[ICMP].type
        m_code = pkt[ICMP].code
        m_payload = bytes(pkt[ICMP].payload).hex()
        m_message = pkt.summary()
        IcmpPacket.add(m_source, m_destination, m_type, m_code, m_payload,m_message)

    @staticmethod
    def requests(iface, count = 10):
        sniff(filter=f'icmp', iface=iface, prn=ICMPRequest.add_data_to_icmp_database, count=count, timeout=3)

    @staticmethod
    def request(source_ip, destination_ip, iface, count = 10):
        sniff(filter=f'icmp and src {source_ip} and dst {destination_ip}', iface=iface, prn=ICMPRequest.add_data_to_icmp_database, count=count, timeout=3)

# TCP包请求
class TcpRequest:
    @staticmethod
    def add_data_to_tcp_database(pkt):
        source_ip = pkt[IP].src
        destination_ip = pkt[IP].dst
        source_port = pkt[TCP].sport
        destination_port = pkt[TCP].dport
        flags = pkt[TCP].flags.flagrepr()
        TcpPacket.add(source_ip, source_port, destination_ip, destination_port, flags)

    @staticmethod
    def requests(iface, count = 50):
        sniff(filter=f'tcp', iface=iface, prn=TcpRequest.add_data_to_tcp_database, count=count, timeout=3)

    @staticmethod
    def request(source_ip, destination_ip, iface, count = 10):
        sniff(filter=f'tcp and src {source_ip} and dst {destination_ip}', iface=iface, prn=TcpRequest.add_data_to_tcp_database, count=count, timeout=3)