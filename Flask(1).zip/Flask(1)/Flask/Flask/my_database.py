﻿from importlib.util import source_hash

from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# 初始化数据库实例（注意：这里不会立即创建数据库连接，只是创建一个实例）  
db = SQLAlchemy()  

# ICMP表
class IcmpPacket(db.Model):  
    # id
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)  
    # 时间
    time = db.Column(db.DateTime, default=db.func.current_timestamp())  
    # 源IP地址
    source_ip = db.Column(db.String(45), nullable=False)  
    # 目的IP地址
    destination_ip = db.Column(db.String(45), nullable=False)  
    # ICMP报文 Type字段
    icmp_type = db.Column(db.Integer, nullable=False)  
    # ICMP报文 Code字段
    icmp_code = db.Column(db.Integer, nullable=False) 
    # ICMP报文 载荷
    payload = db.Column(db.String(80), nullable=False)
    # ICMP报文 MessageBody
    icmp_message_body = db.Column(db.Text, nullable=True)  
  
    def __repr__(self):  
        return f'<IcmpPacket {self.id} - Source: {self.source_ip} -> Destination: {self.destination_ip}>'

    # 向IcmpPacket表添加数据
    def add(m_source, m_destination, m_type, m_code, m_payload, m_message):
        data = IcmpPacket(source_ip=m_source, destination_ip=m_destination, icmp_type=m_type, icmp_code=m_code, payload = m_payload, icmp_message_body=m_message)
        db.session.add(data)
        db.session.commit()
        return 'Packet added successfully!'

    # 根据源IP地址和目的IP地址查找IcmpPacket数据，返回结果按时间排序
    def find(m_source, m_destination):
        datas = IcmpPacket.query.filter_by(source_ip=m_source, destination_ip=m_destination).order_by(IcmpPacket.time.asc()).all()
        return datas

    def all():
        datas = IcmpPacket.query.all()
        return datas

# TCP表
class TcpPacket(db.Model):
    # id
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    # 时间
    time = db.Column(db.DateTime, default=db.func.current_timestamp())
    # 源IP地址
    source_ip = db.Column(db.String(45), nullable=False)
    #源端口
    sour_port=db.Column(db.String(20), nullable=False)
    # 目的IP地址
    destination_ip = db.Column(db.String(45), nullable=False)
    # 目的端口
    des_port=db.Column(db.String(20), nullable=False)
    # TCP报文 标志
    symbol=db.Column(db.String(10), nullable=False)

    def __repr__(self):
        return f'<TcpPacket {self.id} - Source: {self.source_ip} -> Destination: {self.destination_ip}>'

    def add(source_ip,sour_port, destination_ip, des_port,symbol):
        data = TcpPacket(source_ip=source_ip, sour_port=sour_port, destination_ip=destination_ip, des_port=des_port, symbol=symbol)
        db.session.add(data)
        db.session.commit()
        return 'Packet added successfully!'

    def find(source_ip, destination_ip):
        datas = TcpPacket.query.filter_by(source_ip=source_ip, destination_ip=destination_ip).order_by(
        TcpPacket.time.asc()).all()
        return datas

def all():
        datas = TcpPacket.query.all()
        return datas

# 用户表
class UserInfo(db.Model):
    id = db.Column(db.Integer, primary_key=True,  autoincrement=True)  
    username = db.Column(db.String(80), unique=True, nullable=False)  
    password = db.Column(db.String(120), nullable=False)  
  
    def __repr__(self):  
        return f'<UserInfo {self.username}>'

    def add(m_user, m_pwd):
        data = UserInfo(username=m_user, password=m_pwd)
        db.session.add(data)
        db.session.commit()
        return 'User added successfully!'

    def find(m_user):
        user = UserInfo.query.filter_by(username=m_user).first()
        return user
