﻿"""
The flask application package.
"""
from flask import Flask
from Flask.my_database import *
from Flask.request import *


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///icmp_packets.db'  # 使用 SQLite 数据库，你也可以使用其他数据库  
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  

# 初始化数据库，并绑定到Flask应用  
db.init_app(app)  

# 初始化数据库
with app.app_context():
    db.create_all()

import Flask.views
