﻿from datetime import datetime
from flask import redirect, render_template, request, url_for
from Flask import app
from Flask.my_database import *
from Flask.request import *

@app.route('/')
@app.route('/login/', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

    if request.method == 'POST':
        username = request.form['user']
        password = request.form['pwd']

        # 判空
        if username==""or password=="":
            return render_template('login.html', error_msg='用户名或密码不能为空')

        # 查找用户
        exiting_user = UserInfo.find(username)
        # 用户名不存在
        if exiting_user is None:
            return render_template('login.html', error_msg='用户不存在')
        # 密码不正确
        elif password != exiting_user.password:
            return render_template('login.html', error_msg='用户名或密码错误')
        # 密码正确
        else:
            return redirect(url_for('function'))

@app.route('/adduser/', methods=['GET', 'POST'])
def adduser():
    if request.method == "GET":
        return render_template('adduser.html')
    if request.method == 'POST':
        # POST
        username = request.form['user']
        password = request.form['pwd']
        # 判空
        if username==""or password=="":
            return render_template('adduser.html', error_msg='用户名或密码不能为空')
        # 查找用户
        exiting_user = UserInfo.find(username)
        # 用户名是否已占
        if exiting_user is not None:
            return render_template('adduser.html', error_msg='用户名已被占用，注册失败')
        # 添加用户
        else:
            UserInfo.add(username, password)
            return render_template('login.html')

@app.route('/function/', methods=['GET', 'POST'])
def function():
    if request.method == 'GET':
        return render_template('function.html')
    elif request.method == 'POST':
        # 获取源IP地址与目的IP地址
        source_ip = request.form['src_ip']
        destination_ip = request.form['dst_ip']
        # 判空
        if source_ip == "" and destination_ip == "":
            return render_template('function.html', error_msg = '源IP地址或目的IP地址不能为空')
        # 判断ip地址是否合法
        if not is_valid_ip(source_ip) or not is_valid_ip(destination_ip):
            return render_template('function.html', error_msg='源ip地址或目的ip地址输入错误')

        ## 执行POST操作
        # ICMP请求
        if request.form.get('submit') == 'do_ICMPrequest':
            iface2 = NetworkInterface.get_active_interfaces()
            if not iface2  :
                return render_template('function.html', error_msg='未能找到接入的网卡,请检查输入的IP地址是否正确或者检查网络连接')
            else:
                ICMPRequest.request(source_ip, destination_ip, iface2)
                return render_template('function.html', error_msg = '请求成功,获取的数据包已经写入数据库，请点击“查看报文”')
        # ICMP查询
        elif request.form.get('submit') == 'do_ICMPsearch':
            datas = IcmpPacket.find(source_ip, destination_ip)
            if not datas:
                return render_template('function.html', error_msg = '查不到对应结果')
            else:
                return render_template('function.html', icmps = datas)
        # TCP请求
        elif request.form.get('submit') == 'do_TCPrequest':
            # 获取活跃的网卡
            active_interfaces = NetworkInterface.get_active_interfaces()
            if not active_interfaces:
                return render_template('function.html', error_msg='未找到任何已连接的网卡，请检查网络连接')
            else:
                # 遍历活跃的网卡并进行IP匹配
                for iface in active_interfaces:
                    TcpRequest.request(source_ip,destination_ip,iface)
                return render_template('function.html', error_msg='请求成功,获取的数据包已经写入数据库，请点击“查询TCP报文”')
        # TCP查询
        elif request.form.get('submit') == 'do_TCPsearch':
            datas = TcpPacket.find(source_ip, destination_ip)
            if not datas:
                return render_template('function.html', error_msg='查不到对应结果')
            else:
                return render_template('function.html', tcps = datas)
        else :
            return render_template('function.html', error_msg = 'Other error')