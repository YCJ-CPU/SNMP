from scapy.all import sniff, TCP, IP

# 定义处理函数：每当捕获到一个 TCP 报文时调用
def process_packet(packet):
    if packet.haslayer(TCP):
        ip_layer = packet[IP]
        tcp_layer = packet[TCP]

        print(f"源IP: {ip_layer.src} -> 目标IP: {ip_layer.dst}")
        print(f"源端口: {tcp_layer.sport} -> 目标端口: {tcp_layer.dport}")
        print(f"TCP标志: {tcp_layer.flags}")
        print(f"序列号: {tcp_layer.seq}, 确认号: {tcp_layer.ack}\n")

# 开始捕获 TCP 报文，iface 指定网卡接口，count 为捕获数量
print("捕获中，请稍候...")
sniff(filter="tcp", prn=process_packet, iface="WLAN", count=20)